
  public void reduce(LongWritable offset, Iterable<LongWritable> vals,
                        Context context) throws IOException,
                                             InterruptedException {
    // TODO: implement the reduce method
  }
  
