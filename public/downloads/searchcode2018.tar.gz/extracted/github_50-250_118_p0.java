
		public void reduce(Text key, Iterator<IntWritable> values,
				OutputCollector<Text, LongWritable> collector, Reporter reporter)
				throws IOException {
			//Reduce side Business Logic
		}

