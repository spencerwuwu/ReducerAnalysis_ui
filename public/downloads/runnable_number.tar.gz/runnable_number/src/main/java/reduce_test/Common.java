package reduce_test;

public class Common {

	static int maxcount = 2;
	
}
